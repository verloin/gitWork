$('.slider_in01').slick({
  fade: true,
  draggable: false,
  speed: 1000,
  asNavFor: '.slider_in02',
  nextArrow: '<button type="button" class="slick-btn slick-next"></button>',
  prevArrow: '<button type="button" class="slick-btn slick-prev"></button>'
  
});

$('.slider_in02').slick({
  slidesToShow: 5,
  asNavFor: '.slider_in01',
  focusOnSelect: true,
  speed: 1000,
  arrows: false
  // centerMode: true
  // variableWidth: true
});